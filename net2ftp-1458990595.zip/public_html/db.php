<?php

$conn=mysqli_connect('mysql.hostinger.in','u662065187_sas','@toor5','u662065187_atten');
$result=mysqli_query($conn,$_GET['query']);
header('Content-type:application/json');
while($row=$result->fetch_assoc())
{

echo json_encode($row);
}
mysqli_close($conn);

?>